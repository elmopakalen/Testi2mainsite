# PKLN Marketing — pklnmarketing.com

Verkkosivusto PKLN Marketingille. Rakennettu puhtaalla HTML/CSS/JS — ei frameworkeja, ei buildeja.

## Sisältö

- `index.html` — koko sivusto
- `netlify.toml` — Netlify-konfiguraatio

## Deploy Netlifyyn GitHubin kautta

1. Luo GitHub-tili osoitteessa github.com
2. Luo uusi repo: **New repository** → nimi esim. `pkln-site` → Public → Create
3. Lataa tiedostot repoon: **Add file → Upload files** → vedä `index.html` ja `netlify.toml`
4. Mene netlify.com → **Add new site → Import an existing project → GitHub**
5. Valitse tämä repo → Deploy site
6. Mene **Site settings → Domain management → Add custom domain** → kirjoita `pklnmarketing.com`
7. Päivitä DNS-asetukset domainisi rekisteröijällä (A-record → `75.2.60.5`)

## Päivitykset

Tee muutokset `index.html`-tiedostoon GitHubissa → Netlify deployaa automaattisesti.

## Yhteystiedot

- WhatsApp: +358 45 60 44 388
- Email: elmopkln@gmail.com
